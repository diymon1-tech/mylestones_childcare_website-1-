# Mylestones Preschool Website

Ready-to-deploy static website.

## Deploy on Vercel
1. Upload this folder to GitHub.
2. Import the GitHub repo into Vercel.
3. Deploy.

Main file: `index.html`
